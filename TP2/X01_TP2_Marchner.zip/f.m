function val = f(x,y,psi,probleme)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% f :
% Evaluation de la fonction second membre.
%
% SYNOPSIS val = f(x,y)
%          
% INPUT * x,y : les 2 coordonnees du point ou on veut evaluer la fonction.
%
% OUTPUT - val: valeur de la fonction sur ce point.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Probleme de Dirichlet
% Sans terme source, le calcul de f a partir de la donnee u donne:
if strcmp(probleme,'dirichlet')
    f0 = @(x,y) (sin(pi*x).*sin(2*pi*y)*(1+10*pi^2));
    val = f0(x,y);

    %Avec le terme source A, et en fonction de psi, un calcul formel donne l'expression suivante:
    %f = @(x,y,psi) ( sin(pi*x).*sin(2*pi*y).*(1+ 5*pi^2*( sin(psi*x*pi).*sin(psi*y*pi) +2 ) ) - pi*psi*( cos(pi*x).*cos(psi*pi*x) + sin(2*pi*y).*sin(pi*psi*y) ...
        %+ 2*sin(pi*x).*sin(psi*pi*x) + 2*cos(2*pi*y).*cos(pi*psi*y) ) );
    %val = f(x,y,psi);

% Probleme periodique
% Sans terme source, le calcul de f a partir de la donnee u donne:
elseif strcmp(probleme,'periodique')
    f0 = @(x,y) (cos(pi*x).*cos(2*pi*y)*(1+10*pi^2));
    val = f0(x,y);

    %Avec le terme source A, et en fonction de psi, un calcul formel donne l'expression suivante:
    %f = @(x,y,psi) (pi^2*psi*sin(pi*x).*sin(pi*psi*y).*cos(2*pi*y).*cos(pi*psi*x) - 2*pi^2*psi*sin(2*pi*y).*sin(pi*psi*x).*cos(pi*x).*cos(pi*psi*y) + ...
        %5*pi^2*(sin(pi*psi*x).*sin(pi*psi*y) + 2).*cos(pi*x).*cos(2*pi*y) + cos(pi*x).*cos(2*pi*y));
    %val = f(x,y,psi);

else disp('error: ecrire dirichlet ou periodique')
    

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                     fin de la fonction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
